# VELORA – Smart Authentication System
*Your Identity. Your Security. Your Digital Space.*

PHP 8 + MySQL authentication system with a glassmorphism, animated-aurora UI.

## Features
Signup/login with real-time validation, password strength meter, show/hide password, remember-me (hashed selector/validator cookie), forgot/reset password (1-hour single-use tokens), login lockout (5 failures → 15 min), dashboard, name update, password change, secure logout, toast notifications, loading buttons, responsive layout.

## Security
`password_hash`/`password_verify`, PDO prepared statements, CSRF tokens on every POST, HttpOnly + SameSite session cookies, `session_regenerate_id` on login, output escaping, protected pages, hashed reset/remember tokens.

## Run on XAMPP
1. Copy the `velora` folder to `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in the XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin` → **Import** → choose `database/database.sql` → Go.
4. Defaults in `config/database.php` match XAMPP (`root`, empty password). Edit if yours differ.
5. Visit `http://localhost/velora/`.

## Password reset note
There is no mail server locally, so the reset link is shown on the page (`SHOW_RESET_LINK` in `config/database.php`). Set it to `false` and send the link by email in production.

## Manual test checklist
Register → duplicate email → invalid email → mismatched passwords → weak password → login → wrong password ×5 (lockout) → open `dashboard.php` logged out (redirects) → edit name → change password → logout → forgot/reset flow.
