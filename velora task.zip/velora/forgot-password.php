<?php
require __DIR__ . '/includes/auth.php';
$link = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check('forgot-password.php');
    $email = strtolower(trim($_POST['email'] ?? ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { flash('error', 'Enter a valid email address.'); redirect('forgot-password.php'); }
    $s = db()->prepare('SELECT id FROM users WHERE email = ?'); $s->execute([$email]);
    if ($id = $s->fetchColumn()) {
        $tok = bin2hex(random_bytes(32));
        db()->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 1 HOUR))')->execute([$id, hash('sha256', $tok)]);
        if (SHOW_RESET_LINK) $_SESSION['reset_link'] = 'reset-password.php?token=' . $tok;
    }
    flash('success', 'If that email is registered, a reset link has been created.');
    redirect('forgot-password.php');
}
$link = $_SESSION['reset_link'] ?? null; unset($_SESSION['reset_link']);
page_start('Forgot password'); ?>
<section class="card">
  <h1 class="brand">VELORA</h1>
  <h2>Reset your password</h2>
  <form method="post" data-validate novalidate>
    <?= csrf_field() ?>
    <?= field('email', 'email', 'Email address', 'mail', 'data-rule="email"') ?>
    <button class="btn" type="submit"><span class="t">Create reset link</span><span class="loader"></span></button>
  </form>
  <?php if ($link): ?><p class="note">Demo mode (no mail server): <a href="<?= e($link) ?>">open your reset link</a>. It expires in 1 hour.</p><?php endif; ?>
  <p class="alt"><a href="login.php">Back to log in</a></p>
</section>
<?php page_end();
