<?php
require __DIR__ . '/includes/auth.php';
if (current_user()) redirect('dashboard.php');
page_start('Log in'); ?>
<section class="card">
  <h1 class="brand">VELORA</h1><p class="tag">Your Identity. Your Security. Your Digital Space.</p>
  <h2>Welcome back</h2>
  <form action="actions/authenticate.php" method="post" data-validate novalidate>
    <?= csrf_field() ?>
    <?= field('email', 'email', 'Email address', 'mail', 'data-rule="email" autocomplete="email"', old('email')) ?>
    <?= field('password', 'password', 'Password', 'lock', 'autocomplete="current-password"') ?>
    <div class="row"><label class="check"><input type="checkbox" name="remember"><span>Remember me</span></label><a href="forgot-password.php">Forgot password?</a></div>
    <button class="btn" type="submit"><span class="t">Log in</span><span class="loader"></span></button>
  </form>
  <p class="alt">New to Velora? <a href="signup.php">Create an account</a></p>
</section>
<?php page_end();
