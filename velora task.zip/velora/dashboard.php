<?php
require __DIR__ . '/includes/auth.php';
$u = require_login();
$initials = strtoupper(mb_substr($u['full_name'], 0, 1));
page_start('Dashboard'); ?>
<section class="card wide">
  <header class="top"><h1 class="brand">VELORA</h1><a class="btn ghost" href="logout.php">Log out</a></header>
  <h2>Welcome, <?= e(explode(' ', $u['full_name'])[0]) ?></h2>
  <div class="profile">
    <div class="avatar"><?= e($initials) ?></div>
    <dl><dt>Full name</dt><dd><?= e($u['full_name']) ?></dd>
        <dt>Email</dt><dd><?= e($u['email']) ?></dd>
        <dt>Member since</dt><dd><?= e(date('F j, Y', strtotime($u['created_at']))) ?></dd></dl>
  </div>
  <div class="actions"><a class="btn" href="profile.php"><span class="t">Edit profile</span></a><a class="btn ghost" href="profile.php#password">Change password</a></div>
</section>
<?php page_end();
