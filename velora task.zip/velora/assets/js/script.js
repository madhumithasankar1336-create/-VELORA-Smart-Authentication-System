(function () {
  'use strict';
  function toast(msg, type) {
    var box = document.getElementById('toasts'), t = document.createElement('div');
    t.className = 'toast ' + (type || 'success'); t.textContent = msg; box.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 400); }, 4500);
  }
  var tb = document.getElementById('toasts');
  if (tb && tb.dataset.flashMsg) toast(tb.dataset.flashMsg, tb.dataset.flashType);

  document.querySelectorAll('[data-toggle]').forEach(function (b) {
    b.addEventListener('click', function () {
      var i = document.getElementById(b.dataset.toggle), show = i.type === 'password';
      i.type = show ? 'text' : 'password'; b.classList.toggle('on', show);
    });
  });

  function score(p) {
    var s = 0;
    if (p.length >= 8) s++;
    if (/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
    if (/\d/.test(p)) s++;
    if (/[^A-Za-z0-9]/.test(p)) s++;
    return s;
  }
  function check(input) {
    var f = input.closest('.field'), msg = f.querySelector('.err'), v = input.value, rule = input.dataset.rule, e = '';
    if (!v.trim()) e = 'This field is required.';
    else if (rule === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) e = 'Enter a valid email address.';
    else if (rule === 'name' && v.trim().length < 2) e = 'Name must be at least 2 characters.';
    else if (rule === 'password' && score(v) < 4) e = 'Use 8+ characters with upper, lower, number and symbol.';
    else if (rule === 'confirm' && v !== document.getElementById(input.dataset.match).value) e = 'Passwords do not match.';
    msg.textContent = e; f.classList.toggle('bad', !!e); f.classList.toggle('ok', !e);
    return !e;
  }
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    var fields = form.querySelectorAll('input[data-rule]');
    fields.forEach(function (i) {
      i.addEventListener('input', function () {
        check(i);
        if (i.dataset.rule === 'password') {
          var c = form.querySelector('[data-rule="confirm"]'); if (c && c.value) check(c);
        }
      });
    });
    form.addEventListener('submit', function (ev) {
      var ok = true;
      fields.forEach(function (i) { if (!check(i)) ok = false; });
      form.querySelectorAll('input[required]:not([data-rule]):not([type=checkbox]):not([type=hidden])').forEach(function (i) { if (!i.value) ok = false; });
      var terms = form.querySelector('[name=terms]');
      if (terms && !terms.checked) { ok = false; toast('Please accept the Terms and Conditions.', 'error'); }
      if (!ok) { ev.preventDefault(); return; }
      var b = form.querySelector('.btn[type=submit]'); if (b) b.classList.add('loading');
    });
  });

  var pw = document.getElementById('password'), meter = document.getElementById('meter');
  if (pw && meter) pw.addEventListener('input', function () {
    var s = score(pw.value), l = !pw.value ? '' : s <= 2 ? 'weak' : s === 3 ? 'medium' : 'strong';
    meter.className = 'meter ' + l;
    document.getElementById('meterText').textContent = l ? l[0].toUpperCase() + l.slice(1) : 'Strength';
  });

  var glow = document.getElementById('glow');
  window.addEventListener('pointermove', function (e) { glow.style.left = e.clientX + 'px'; glow.style.top = e.clientY + 'px'; });

  var c = document.getElementById('particles'), x = c.getContext('2d'), P = [], W, H;
  function size() { W = c.width = innerWidth; H = c.height = innerHeight; }
  size(); addEventListener('resize', size);
  for (var k = 0; k < 45; k++) P.push({ x: Math.random() * 2000, y: Math.random() * 1200, r: Math.random() * 2 + 0.6, v: Math.random() * 0.4 + 0.1, a: Math.random() * 6.28 });
  (function draw() {
    x.clearRect(0, 0, W, H);
    P.forEach(function (p) {
      p.y -= p.v; p.a += 0.01;
      if (p.y < -5) { p.y = H + 5; p.x = Math.random() * W; }
      x.beginPath(); x.arc(p.x + Math.sin(p.a) * 20, p.y, p.r, 0, 6.28);
      x.fillStyle = 'rgba(92,255,196,' + (0.35 + Math.sin(p.a) * 0.25) + ')'; x.shadowColor = '#5cffc4'; x.shadowBlur = 10; x.fill();
    });
    requestAnimationFrame(draw);
  })();
})();
