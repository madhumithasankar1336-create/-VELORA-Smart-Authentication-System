<?php
require __DIR__ . '/includes/auth.php';
$tok = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$s = db()->prepare('SELECT id, user_id FROM password_resets WHERE token_hash = ? AND used = 0 AND expires_at > NOW()');
$s->execute([hash('sha256', $tok)]);
$r = $s->fetch();
if (!$r) { flash('error', 'This reset link is invalid or has expired.'); redirect('forgot-password.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check('reset-password.php?token=' . urlencode($tok));
    $p = $_POST['password'] ?? '';
    if (!strong_password($p)) flash('error', 'Password needs 8+ characters with upper, lower, number and symbol.');
    elseif ($p !== ($_POST['confirm_password'] ?? '')) flash('error', 'Passwords do not match.');
    else {
        db()->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $r['user_id']]);
        db()->prepare('UPDATE password_resets SET used = 1 WHERE user_id = ?')->execute([$r['user_id']]);
        db()->prepare('DELETE FROM remember_tokens WHERE user_id = ?')->execute([$r['user_id']]);
        flash('success', 'Password reset. Log in with your new password.');
        redirect('login.php');
    }
    redirect('reset-password.php?token=' . urlencode($tok));
}
page_start('Reset password'); ?>
<section class="card">
  <h1 class="brand">VELORA</h1>
  <h2>Choose a new password</h2>
  <form method="post" data-validate novalidate>
    <?= csrf_field() ?><input type="hidden" name="token" value="<?= e($tok) ?>">
    <?= field('password', 'password', 'New password', 'lock', 'data-rule="password" autocomplete="new-password"') ?>
    <div class="meter" id="meter"><i></i><i></i><i></i><i></i><span id="meterText">Strength</span></div>
    <?= field('confirm_password', 'password', 'Confirm password', 'lock', 'data-rule="confirm" data-match="password" autocomplete="new-password"') ?>
    <button class="btn" type="submit"><span class="t">Reset password</span><span class="loader"></span></button>
  </form>
</section>
<?php page_end();
