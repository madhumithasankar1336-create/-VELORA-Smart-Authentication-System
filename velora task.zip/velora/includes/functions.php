<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
    session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/csrf.php';

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function redirect(string $u): void { header('Location: ' . $u); exit; }
function flash(?string $type = null, ?string $msg = null) {
    if ($type !== null) { $_SESSION['flash'] = ['t' => $type, 'm' => $msg]; return; }
    $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f;
}
function old(string $k): string { return e($_SESSION['old'][$k] ?? ''); }
function clean_name(string $n): string { return trim(preg_replace('/\s+/', ' ', strip_tags($n))); }
function strong_password(string $p): bool {
    return strlen($p) >= 8 && preg_match('/[A-Z]/', $p) && preg_match('/[a-z]/', $p) && preg_match('/\d/', $p) && preg_match('/[^A-Za-z0-9]/', $p);
}
function icon(string $n): string {
    $p = [
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
        'lock' => '<rect x="5" y="11" width="14" height="9" rx="3"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>',
        'eye'  => '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    ];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p[$n] . '</svg>';
}
function field(string $id, string $type, string $label, string $icon, string $extra = '', string $value = ''): string {
    $toggle = $type === 'password' ? '<button type="button" class="toggle" data-toggle="' . $id . '" aria-label="Show or hide password">' . icon('eye') . '</button>' : '';
    return '<div class="field"><label for="' . $id . '">' . $label . '</label><div class="control"><span class="ico">' . icon($icon) . '</span>'
        . '<input id="' . $id . '" name="' . $id . '" type="' . $type . '" value="' . $value . '" placeholder=" " required ' . $extra . '>' . $toggle . '</div><small class="err"></small></div>';
}
function page_start(string $title, string $cls = ''): void {
    $f = flash();
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<title>' . e($title) . ' · VELORA</title><link rel="preconnect" href="https://fonts.googleapis.com">'
        . '<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700&display=swap" rel="stylesheet">'
        . '<link rel="stylesheet" href="assets/css/style.css"></head><body class="' . $cls . '">'
        . '<div class="bg"><div class="aurora a1"></div><div class="aurora a2"></div><div class="orb o1"></div><div class="orb o2"></div>'
        . '<i class="shape s1"></i><i class="shape s2"></i><i class="shape s3"></i><canvas id="particles"></canvas><div id="glow"></div></div>'
        . '<div id="toasts" data-flash-type="' . e($f['t'] ?? '') . '" data-flash-msg="' . e($f['m'] ?? '') . '"></div><main class="stage">';
}
function page_end(): void {
    unset($_SESSION['old']);
    echo '</main><script src="assets/js/script.js"></script></body></html>';
}
