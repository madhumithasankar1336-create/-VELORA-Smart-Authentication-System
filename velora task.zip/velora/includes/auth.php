<?php
require_once __DIR__ . '/functions.php';
const MAX_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

function login_user(int $id): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
}
function current_user(): ?array {
    if (empty($_SESSION['user_id']) && !empty($_COOKIE['velora_remember'])) {
        $parts = explode(':', $_COOKIE['velora_remember']);
        if (count($parts) === 2) {
            $s = db()->prepare('SELECT user_id, validator_hash FROM remember_tokens WHERE selector = ? AND expires_at > NOW()');
            $s->execute([$parts[0]]);
            $r = $s->fetch();
            if ($r && hash_equals($r['validator_hash'], hash('sha256', $parts[1]))) login_user((int)$r['user_id']);
        }
    }
    if (empty($_SESSION['user_id'])) return null;
    $s = db()->prepare('SELECT id, full_name, email, created_at FROM users WHERE id = ?');
    $s->execute([$_SESSION['user_id']]);
    return $s->fetch() ?: null;
}
function require_login(): array {
    $u = current_user();
    if (!$u) { flash('error', 'Please log in to continue.'); redirect('login.php'); }
    return $u;
}
function set_remember(int $uid): void {
    $sel = bin2hex(random_bytes(12)); $val = bin2hex(random_bytes(32)); $exp = time() + 30 * 86400;
    db()->prepare('INSERT INTO remember_tokens (user_id, selector, validator_hash, expires_at) VALUES (?,?,?,?)')
        ->execute([$uid, $sel, hash('sha256', $val), date('Y-m-d H:i:s', $exp)]);
    setcookie('velora_remember', "$sel:$val", ['expires' => $exp, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
}
function clear_remember(): void {
    if (!empty($_COOKIE['velora_remember'])) {
        db()->prepare('DELETE FROM remember_tokens WHERE selector = ?')->execute([explode(':', $_COOKIE['velora_remember'])[0]]);
    }
    setcookie('velora_remember', '', ['expires' => time() - 3600, 'path' => '/', 'httponly' => true]);
}
function is_locked(string $email): int {
    $s = db()->prepare('SELECT COUNT(*) c, MIN(attempted_at) f FROM login_attempts WHERE email = ? AND attempted_at > (NOW() - INTERVAL ' . LOCK_MINUTES . ' MINUTE)');
    $s->execute([$email]);
    $r = $s->fetch();
    if ((int)$r['c'] < MAX_ATTEMPTS) return 0;
    return max(1, (int)ceil((strtotime($r['f']) + LOCK_MINUTES * 60 - time()) / 60));
}
function record_failure(string $email): void {
    db()->prepare('INSERT INTO login_attempts (email, ip_address, attempted_at) VALUES (?,?,NOW())')->execute([$email, $_SERVER['REMOTE_ADDR'] ?? '0']);
}
function clear_failures(string $email): void { db()->prepare('DELETE FROM login_attempts WHERE email = ?')->execute([$email]); }
