<?php
require __DIR__ . '/../includes/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('../login.php');
csrf_check('../login.php');
$email = strtolower(trim($_POST['email'] ?? '')); $p = $_POST['password'] ?? '';
$_SESSION['old'] = ['email' => $email];
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $p === '') { flash('error', 'Enter your email and password.'); redirect('../login.php'); }
if ($m = is_locked($email)) { flash('error', "Too many failed attempts. Try again in $m minute(s)."); redirect('../login.php'); }
$s = db()->prepare('SELECT id, password FROM users WHERE email = ?'); $s->execute([$email]);
$u = $s->fetch();
if (!$u || !password_verify($p, $u['password'])) {
    record_failure($email);
    flash('error', 'Incorrect email or password.');
    redirect('../login.php');
}
clear_failures($email);
unset($_SESSION['old']);
login_user((int)$u['id']);
if (!empty($_POST['remember'])) set_remember((int)$u['id']);
redirect('../dashboard.php');
