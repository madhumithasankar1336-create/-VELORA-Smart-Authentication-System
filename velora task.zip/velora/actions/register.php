<?php
require __DIR__ . '/../includes/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('../signup.php');
csrf_check('../signup.php');
$name = clean_name($_POST['full_name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? ''));
$p = $_POST['password'] ?? ''; $c = $_POST['confirm_password'] ?? '';
$_SESSION['old'] = ['full_name' => $name, 'email' => $email];
$err = null;
if ($name === '' || $email === '' || $p === '' || $c === '') $err = 'All fields are required.';
elseif (mb_strlen($name) < 2 || mb_strlen($name) > 100) $err = 'Name must be 2–100 characters.';
elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Enter a valid email address.';
elseif (!strong_password($p)) $err = 'Password needs 8+ characters with upper, lower, number and symbol.';
elseif ($p !== $c) $err = 'Passwords do not match.';
elseif (empty($_POST['terms'])) $err = 'Please accept the Terms and Conditions.';
else {
    $s = db()->prepare('SELECT id FROM users WHERE email = ?'); $s->execute([$email]);
    if ($s->fetch()) $err = 'An account with this email already exists.';
}
if ($err) { flash('error', $err); redirect('../signup.php'); }
db()->prepare('INSERT INTO users (full_name, email, password) VALUES (?,?,?)')->execute([$name, $email, password_hash($p, PASSWORD_DEFAULT)]);
unset($_SESSION['old']);
flash('success', 'Account created. You can log in now.');
redirect('../login.php');
