<?php
require __DIR__ . '/../includes/auth.php';
$u = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('../profile.php');
csrf_check('../profile.php');
if (($_POST['action'] ?? '') === 'name') {
    $n = clean_name($_POST['full_name'] ?? '');
    if (mb_strlen($n) < 2 || mb_strlen($n) > 100) { flash('error', 'Name must be 2–100 characters.'); redirect('../profile.php'); }
    db()->prepare('UPDATE users SET full_name = ? WHERE id = ?')->execute([$n, $u['id']]);
    flash('success', 'Profile updated.');
} elseif (($_POST['action'] ?? '') === 'password') {
    $s = db()->prepare('SELECT password FROM users WHERE id = ?'); $s->execute([$u['id']]);
    $hash = $s->fetchColumn();
    $new = $_POST['new_password'] ?? '';
    if (!password_verify($_POST['current_password'] ?? '', $hash)) flash('error', 'Current password is incorrect.');
    elseif (!strong_password($new)) flash('error', 'New password needs 8+ characters with upper, lower, number and symbol.');
    elseif ($new !== ($_POST['confirm_password'] ?? '')) flash('error', 'New passwords do not match.');
    else {
        db()->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
        db()->prepare('DELETE FROM remember_tokens WHERE user_id = ?')->execute([$u['id']]);
        session_regenerate_id(true);
        flash('success', 'Password changed.');
    }
}
redirect('../profile.php');
