<?php
require __DIR__ . '/includes/auth.php';
$u = require_login();
page_start('Profile'); ?>
<section class="card wide">
  <header class="top"><h1 class="brand">VELORA</h1><a class="btn ghost" href="dashboard.php">Back</a></header>
  <h2>Edit profile</h2>
  <form action="actions/update-profile.php" method="post" data-validate novalidate>
    <?= csrf_field() ?><input type="hidden" name="action" value="name">
    <?= field('full_name', 'text', 'Full name', 'user', 'data-rule="name" maxlength="100"', e($u['full_name'])) ?>
    <button class="btn" type="submit"><span class="t">Save name</span><span class="loader"></span></button>
  </form>
  <h2 id="password">Change password</h2>
  <form action="actions/update-profile.php" method="post" data-validate novalidate>
    <?= csrf_field() ?><input type="hidden" name="action" value="password">
    <?= field('current_password', 'password', 'Current password', 'lock', 'autocomplete="current-password"') ?>
    <?= field('new_password', 'password', 'New password', 'lock', 'data-rule="password" autocomplete="new-password"') ?>
    <?= field('confirm_password', 'password', 'Confirm new password', 'lock', 'data-rule="confirm" data-match="new_password" autocomplete="new-password"') ?>
    <button class="btn" type="submit"><span class="t">Update password</span><span class="loader"></span></button>
  </form>
</section>
<?php page_end();
