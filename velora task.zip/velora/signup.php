<?php
require __DIR__ . '/includes/auth.php';
if (current_user()) redirect('dashboard.php');
page_start('Create account'); ?>
<section class="card">
  <h1 class="brand">VELORA</h1><p class="tag">Your Identity. Your Security. Your Digital Space.</p>
  <h2>Create your account</h2>
  <form action="actions/register.php" method="post" data-validate novalidate>
    <?= csrf_field() ?>
    <?= field('full_name', 'text', 'Full name', 'user', 'data-rule="name" autocomplete="name" maxlength="100"', old('full_name')) ?>
    <?= field('email', 'email', 'Email address', 'mail', 'data-rule="email" autocomplete="email"', old('email')) ?>
    <?= field('password', 'password', 'Password', 'lock', 'data-rule="password" autocomplete="new-password"') ?>
    <div class="meter" id="meter"><i></i><i></i><i></i><i></i><span id="meterText">Strength</span></div>
    <?= field('confirm_password', 'password', 'Confirm password', 'lock', 'data-rule="confirm" data-match="password" autocomplete="new-password"') ?>
    <label class="check"><input type="checkbox" name="terms" required><span>I accept the Terms and Conditions</span></label>
    <button class="btn" type="submit"><span class="t">Create account</span><span class="loader"></span></button>
  </form>
  <p class="alt">Already registered? <a href="login.php">Log in</a></p>
</section>
<?php page_end();
